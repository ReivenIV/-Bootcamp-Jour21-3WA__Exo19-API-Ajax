// clef api
const API_KEY = '840523a722e0ffc0a860538562e81c5e';
// base url image
const url_img = 'https://image.tmdb.org/t/p/w500';

// function ajax qui recupèrent tous les film en fonction d'un mot clef
//callback à l'intérieur execute affichage d'une liste
function getMovies(movie) {
    axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${movie}`)
    .then((response)=>{
        let res = response.data.results
        
        let ul = document.createElement("ul")
        
        for(let i=0; i < res.length; i++){
            let li = document.createElement("li")
            li.dataset.id = res[i].id
            li.innerHTML = res[i].title
            //on crée l'événement ici si nous n'utilisons pas jquery
            li.addEventListener("click", onClickShowOneMovie)
            ul.appendChild(li)
        }
        
        document.querySelector("#list").appendChild(ul)
    })
    .catch(err=>console.log(err))
}


//fonction ajax qui récupère les détails d'un film en fonction de son id
// callback à l'intérieur execute l'affichage d'un film
function showOneMovie(id) {
    console.log(id)
    axios.get(`https://api.themoviedb.org/3/movie/${id}?api_key=${API_KEY}`)
    .then((response)=>{
        
        let res = response.data
        let result = document.querySelector("#result")
        result.innerHTML = ""
        //affichage des infos du film dans la div #result
        let img = document.createElement("img")
        img.src = url_img + res.poster_path
        
        let h3 = document.createElement("h3")
        h3.innerHTML = res.original_title
        
        let date = document.createElement("p")
        date.innerHTML = res.release_date
        
        let description = document.createElement("p")
        description.innerHTML = res.overview
        
        result.appendChild(img)
        result.appendChild(h3)
        result.appendChild(date)
        result.appendChild(description)
        //boucle qui va parcouris les companies et qui va appeler la fonction en dessous
        for(let i=0; i < res.production_companies.length; i++){
            getCompanyWebSite(res.production_companies[i].id)
        }
        
        /*res.production_companies.forEach((company)=>{
            getCompanyWebSite(company.id)
        })*/
    })
    .catch(err=>console.log(err))
}

//requète ajax de récupération des données d'une company
function getCompanyWebSite(id) {
    axios.get(`https://api.themoviedb.org/3/company/${id}?api_key=${API_KEY}`)
    .then((response)=>{
        displayCompany(response.data)
    })
    .catch(err=>console.log(err))
}
//fonction callback d'affichage des données d'une company
function displayCompany(response) {
    console.log(response)
    let a = document.createElement("a")
    a.style.display = "block";
    if(response.homepage === ""){
        a.href = "#"
    }else{
        a.href = response.homepage
    }
    
    a.innerHTML = response.name
    
    document.querySelector("#result").appendChild(a)
}
